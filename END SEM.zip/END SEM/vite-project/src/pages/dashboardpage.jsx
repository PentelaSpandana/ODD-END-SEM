import React from 'react';
import { useAuth } from '../auth/AuthContext';

export function Dashboard() {
  const { user, logout } = useAuth();

  return (
    <div>
      <h2>Welcome, {user?.name}</h2>
      <p>This is the student portal dashboard — only for authorized users.</p>
      <button onClick={logout}>Logout</button>
    </div>
  );
}
