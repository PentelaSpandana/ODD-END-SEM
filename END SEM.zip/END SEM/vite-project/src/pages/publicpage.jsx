import React from 'react';

export function PublicPage() {
  return <h2>Public Page (anyone can access)</h2>;
}
